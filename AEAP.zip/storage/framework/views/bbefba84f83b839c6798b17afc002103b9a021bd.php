
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/main.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('/assets/bootstrap/dist/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/bootstrap/dist/css/bootstrap-grid.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/bootstrap/dist/css/bootstrap-reboot.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/fontAwesome_css/css/all.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/slick.css')); ?>">


    <script src="<?php echo e(asset('/assets/js/main.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/assets/bootstrap/dist/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/bootstrap/dist/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/bootstrap/dist/js/tooltip.js')); ?>"></script>


    <script src="<?php echo e(asset('/assets/css/fontAwesome_css/js/all.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.6/js/swiper.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.6/js/swiper.min.js"></script>

    <title><?php echo $__env->yieldContent('title'); ?></title>

<?php /**PATH F:\Projects\php\laravel\AEAP\resources\views/layouts/head.blade.php ENDPATH**/ ?>