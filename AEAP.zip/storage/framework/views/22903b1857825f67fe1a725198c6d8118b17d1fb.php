<!--TOP NAVIGATION-->
<header id="header">
    <div class="topnav" id="myTopnav">
        <a href="#"><img class="logo" src="<?php echo e(URL::to('/assets/images/logo.jpeg')); ?>" alt=""></a>
        <a id="active">Carter-Machinery</a>
        <a href="<?php echo e(route('home')); ?>">Home</a>
        <a href="<?php echo e(route('home')); ?>">Who we are</a>
        <a href="<?php echo e(route('home')); ?>">Brands</a>
        <a href="#about">About</a>
        <a href="#contact">Contact</a>


        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="NavBar()">&#9776;</a>
    </div>
</header>
<?php /**PATH F:\Projects\php\laravel\AEAP\resources\views/layouts/header.blade.php ENDPATH**/ ?>