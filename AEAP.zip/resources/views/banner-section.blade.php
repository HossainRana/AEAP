<style>
    /*DEFAULT*/
    *{
        box-sizing:border-box;
    }

    :root{
        --white:#fff;
        --darkred:#cd2027;
        --darkblue:#061221;
    }

    body{
        margin: 0;
        overflow-x: hidden;
        background-color: #061221;
        color:#fff;
        font-family: 'Source Sans Pro', sans-serif;
    }

    a,li,button,i,.button{
        text-decoration: none;
        outline: none !important;
        list-style: none;
        transition: 0.5s;
    }

    .title{
        font-family: 'Merriweather', serif;
        font-size:3vw;
        font-weight:600;
        text-transform: uppercase;
    }

    .sub-title{
        font-size: 1vw;
        font-weight: 200;
        width: 450px;
        line-height: 35px;
    }

    .btn1{
        display:inline-block;
        text-align:center;
        border-radius:40px;
        padding:20px 40px;
    }

    .btn1{
        background-color:var(--darkblue);
        color:var(--white);
    }

    .btn1:hover{
        background:var(--white);
        color:var(--darkred);
    }


    @media (max-width:920px){
        .title{
            font-size:1.3em;
        }
        .sub-title{
            font-size:1em;
        }
        .btn1{
            padding:15px 30px;
        }
    }

    /*TOP NAVIGATION*/
    header{
        position:fixed;
        top:2rem;
        width:100%;
        z-index:99999;
        transition:0.5s;
    }

    .topnav {
        overflow: hidden;
        background-color: rgba(6, 18, 33, 0.8);
        width:80%;
        margin:auto;
        box-shadow:0px 6px 16px -6px rgba(1,1,1,0.7);
        transition:0.5s;
    }

    .topnav a {
        float: left;
        display: block;
        color: #f2f2f2;
        text-align: center;
        padding: 24px 16px;
        margin:auto 1rem;
        text-decoration: none;
        font-size: 17px;
        position:relative;
    }

    .logo{
        width:40px;
        position:absolute;
        top:1rem;
        background-color:#fff;
        border-radius:5px;
    }

    #icon{
        float:right;
    }

    #active{
        display:flex;
        font-weight:bold;
        font-family: 'Titillium Web', sans-serif;
    }

    #active:hover{
        color:#fff;
    }

    .topnav .icon {
        display: none;
    }

    .dropdown {
        float: left;
        overflow: hidden;
    }

    .dropdown .dropbtn {
        font-size: 17px;
        border: none;
        outline: none;
        color: white;
        padding: 24px 16px;
        background-color: inherit;
        font-family: inherit;
        margin:auto 1rem;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
        border-top:2px solid #cd2027;
    }

    .dropdown-content a {
        float: none;
        color: black;
        padding: 8px 16px;
        margin:auto 0rem;
        text-decoration: none;
        display: block;
        text-align: left;
    }

    .topnav a:hover, .dropdown:hover .dropbtn {
        color: #cd2027;
    }

    .dropdown-content a:hover {
        background-color: #ddd;
        color: black;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    @media screen and (max-width: 1120px) {
        .logo{
            width:20px;
            position:static;
        }
        .dropdown .dropbtn {
            padding: 14px 16px;
        }
        .topnav a:not(:first-child), .dropdown .dropbtn {
            display: none;
        }
        .topnav a.icon {
            float: right;
            display: block;
        }
        #active{
            display:none;
        }
    }

    @media screen and (max-width: 1120px) {
        .topnav.responsive {position: relative;}
        .topnav.responsive .icon {
            position: absolute;
            right: 0;
            top: 0;
        }
        .topnav.responsive a {
            float: none;
            display: block;
            text-align: left;
            padding: 14px 16px;
        }
        .topnav.responsive .dropdown {float: none;}
        .topnav.responsive .dropdown-content {position: relative;}
        .topnav.responsive .dropdown .dropbtn {
            display: block;
            width: 100%;
            text-align: left;
        }
    }

    /*BANNER*/
    .banner{
        width:100%;
        height:100vh;
        display:flex;
        position:relative;
        background: linear-gradient(rgba(1,1,1,.5), rgba(1,1,1,.5)), url("././public/assets/images/banner-02.jpg");
        background-attachment:fixed;
        background-size:cover;
        background-position:right;
    }

    .banner .content{
        height:100%;
        position:relative;
        background-color: transparent;
        /*background-image: linear-gradient(260deg, var(--darkred) 44%, var(--darkred) 38%);*/
        transform: skew(20deg);
        position:absolute;
        /*left:-10%;*/
        width:70%;
        display:flex;
        align-items:center;
        justify-content:left;
    }

    .banner .content section{
        padding:0 10rem;
        transform: skew(-20deg);
        width:100%;
        color:var(--white);
        letter-spacing:0.08em;
        z-index:11111111;
    }

    @media (max-width:1120px){
        .banner .content section{
            padding:0 8rem;
        }
    }

    @media (max-width:920px){
        .banner{
            background-attachment:local;
        }
        .banner .content{
            position:static;
            left:0%;
            width:100%;
            background-image:none;
        }
        .banner .content section{
            padding:0rem;
            padding:2rem;
        }
    }
</style>




<!--BANNER-->
<div class="banner">
    <div class="content">
        <section>
            <h1 class="title">Trucks <br>Articulated </h1>
            <h4 class="sub-title">The articulated joint dumpers with three axles combine high handling capacity with sate of the art drive technology</h4>
            <a href="#Auctions" class="btn1">Show More</a>
        </section>
    </div>
</div>


<script>
    //TOP NAVIGATION
    function NavBar() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }
    window.onscroll = function() {scrollFunction()};
    function scrollFunction() {
        if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
            document.getElementById("myTopnav").style.width = "100%";
            document.getElementById("myTopnav").style.backgroundColor = "rgba(6, 18, 33, 1)";
            document.getElementById("header").style.position = "fixed";
            document.getElementById("header").style.top = "0%";
        } else {
            document.getElementById("myTopnav").style.width = "80%";
            document.getElementById("myTopnav").style.backgroundColor = "rgba(6, 18, 33, 0.8)";
            document.getElementById("header").style.position = "fixed";
            document.getElementById("header").style.top = "2rem";
        }
    }


</script>
